import { useState } from 'react'
import BookList from './components/BookList.jsx'
import BookForm from './components/BookForm.jsx'
import osLusiadasCapa from './assets/oslusiadas.png'
import ensaioCapa from './assets/ensaiossobreaceregueira.jpg'
import principezinhoCapa from './assets/oprincipezinho.png'

// Array de objetos com os livros iniciais
const livrosIniciais = [
  {
    id: 1,
    titulo: 'Os Lusíadas',
    autor: 'Luís de Camões',
    ano: 1572,
    capa: osLusiadasCapa,
    sinopse: 'Poema épico que narra a viagem de Vasco da Gama à Índia e a história de Portugal.',
  },
  {
    id: 2,
    titulo: 'Ensaio sobre a Cegueira',
    autor: 'José Saramago',
    ano: 1995,
    capa: ensaioCapa,
    sinopse: 'Uma epidemia de cegueira branca atinge uma cidade e revela o pior e o melhor das pessoas.',
  },
  {
    id: 3,
    titulo: 'O Principezinho',
    autor: 'Antoine de Saint-Exupéry',
    ano: 1943,
    capa: principezinhoCapa,
    sinopse: 'Um piloto encontra no deserto um pequeno príncipe vindo de outro planeta.',
  },
]

function App() {
  // Estado com a lista de livros
  const [livros, setLivros] = useState(livrosIniciais)

  // Função passada por props ao formulário
  function adicionarLivro(novoLivro) {
    setLivros([...livros, novoLivro])
  }

  return (
    <div>
      <h1>Catálogo de Livros</h1>
      <p>Explore os livros e adicione os seus favoritos ao catálogo.</p>

      <h2>Livros</h2>
      <BookList livros={livros} />

      <h2>Adicionar novo livro</h2>
      <BookForm onAdicionar={adicionarLivro} />
    </div>
  )
}

export default App
