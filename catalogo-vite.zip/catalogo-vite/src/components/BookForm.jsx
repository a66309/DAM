import { useState } from 'react'

function BookForm({ onAdicionar }) {
  // Campos controlados com useState
  const [titulo, setTitulo] = useState('')
  const [autor, setAutor] = useState('')
  const [ano, setAno] = useState('')
  const [capa, setCapa] = useState(null)
  const [sinopse, setSinopse] = useState('')

  function handleSubmit(evento) {
    evento.preventDefault() // evita recarregar a página

    const novoLivro = {
      id: Date.now(),
      titulo: titulo,
      autor: autor,
      ano: Number(ano),
      capa: URL.createObjectURL(capa),
      sinopse: sinopse,
    }

    onAdicionar(novoLivro)

    // Limpar o formulário
    setTitulo('')
    setAutor('')
    setAno('')
    setCapa(null)
    setSinopse('')
    evento.currentTarget.reset()
  }

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Título: </label>
        <input
          type="text"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          required
        />
      </div>

      <div>
        <label>Autor: </label>
        <input
          type="text"
          value={autor}
          onChange={(e) => setAutor(e.target.value)}
          required
        />
      </div>

      <div>
        <label>Ano: </label>
        <input
          type="number"
          value={ano}
          onChange={(e) => setAno(e.target.value)}
          required
        />
      </div>

      <div>
        <label htmlFor="capa">Buscar imagem da capa: </label>
        <input
          id="capa"
          type="file"
          accept="image/*"
          onChange={(e) => setCapa(e.target.files?.[0] ?? null)}
          required
        />
      </div>

      <div>
        <label>Opinião: </label>
        <textarea
          value={sinopse}
          onChange={(e) => setSinopse(e.target.value)}
          required
        />
      </div>

      <button type="submit">Adicionar livro</button>
    </form>
  )
}

export default BookForm
