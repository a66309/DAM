import BookCard from './BookCard.jsx'

function BookList({ livros }) {
  return (
    <div>
      {/* map() para apresentar a lista, com key única em cada item */}
      {livros.map((livro) => (
        <BookCard key={livro.id} livro={livro} />
      ))}
    </div>
  )
}

export default BookList
