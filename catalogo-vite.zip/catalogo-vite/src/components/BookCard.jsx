import { useState } from 'react'

function BookCard({ livro }) {
  // Estado: mostrar ou ocultar os detalhes deste livro
  const [mostrarDetalhes, setMostrarDetalhes] = useState(false)

  return (
    <div>
      <img src={livro.capa} alt={'Capa de ' + livro.titulo} width="120" />
      <h3>{livro.titulo}</h3>
      <p>{livro.autor}</p>

      <button onClick={() => setMostrarDetalhes(!mostrarDetalhes)}>
        {mostrarDetalhes ? 'Ocultar detalhes' : 'Ver detalhes'}
      </button>

      {/* Renderização condicional: só aparece se mostrarDetalhes for true */}
      {mostrarDetalhes && (
        <div>
          <p><strong>Ano:</strong> {livro.ano}</p>
          <p><strong>Opinião:</strong> {livro.sinopse}</p>
        </div>
      )}

      <hr />
    </div>
  )
}

export default BookCard
